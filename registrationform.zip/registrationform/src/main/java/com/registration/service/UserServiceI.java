package com.registration.service;

import com.registration.entity.User;

public interface UserServiceI {
	public void registerUser(User user);
}
