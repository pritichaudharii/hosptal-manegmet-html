package com.registration.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.registration.entity.StudentDetails;



public interface StudentDetailsDaoI extends JpaRepository<StudentDetails, Integer> {
	
}
